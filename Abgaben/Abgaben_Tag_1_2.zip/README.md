# UEK 285

Das ist das Repository für das Modul 295 im ZLI. Es geht um Backend-Realisierung mit Node.js.

## LearnYouNode

Alle LearnYouNode Challenges können im Folder [LearnYouNode](LearnYouNode/) gefunden werden.

## ZLI Aufgaben

Alle ZLI Aufgaben können im Folder [Exercices](Exercices/) gefunden werden.
